CREATE VIEW period_year_ein_v AS
  SELECT
    `p`.`year`   AS `year`,
    `t`.`betrag` AS `Betrag`
  FROM (`haushaltsdaten`.`transaktion` `t` LEFT JOIN `haushaltsdaten`.`period_year` `p`
      ON ((`p`.`year` = year(`t`.`datum`))))
  WHERE (`t`.`zahlungsart` = 'Einzahlung')
  UNION SELECT
          `p`.`year` AS `year`,
          NULL       AS `NULL`
        FROM (`haushaltsdaten`.`period_year` `p` LEFT JOIN `haushaltsdaten`.`transaktion` `t`
            ON ((`p`.`year` = year(`t`.`datum`))));
