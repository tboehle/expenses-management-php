CREATE VIEW period_day_ein_v AS
  SELECT
    `p`.`day_key` AS `day_key`,
    `t`.`betrag`  AS `betrag`
  FROM (`haushaltsdaten`.`transaktion` `t` LEFT JOIN `haushaltsdaten`.`period_day` `p`
      ON (((`p`.`year_no` = year(`t`.`datum`)) AND (`p`.`month_no` = month(`t`.`datum`)) AND
           (`p`.`day_no` = dayofmonth(`t`.`datum`)))))
  WHERE (`t`.`zahlungsart` = 'Einzahlung')
  UNION SELECT
          `p`.`day_key` AS `day_key`,
          NULL          AS `NULL`
        FROM (`haushaltsdaten`.`period_day` `p` LEFT JOIN `haushaltsdaten`.`transaktion` `t`
            ON (((`p`.`year_no` = year(`t`.`datum`)) AND (`p`.`month_no` = month(`t`.`datum`)) AND
                 (`p`.`day_no` = dayofmonth(`t`.`datum`)))));
