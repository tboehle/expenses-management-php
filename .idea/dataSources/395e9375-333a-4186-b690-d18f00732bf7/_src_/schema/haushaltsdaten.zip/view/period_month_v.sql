CREATE VIEW period_month_v AS
  SELECT
    `p`.`month_key` AS `month_key`,
    `t`.`betrag`    AS `betrag`
  FROM (`haushaltsdaten`.`period_month` `p` LEFT JOIN `haushaltsdaten`.`transaktion` `t`
      ON (((`p`.`month_no` = month(`t`.`datum`)) AND (`p`.`year_no` = year(`t`.`datum`)))))
  WHERE (`t`.`zahlungsart` = 'Auszahlung')
  GROUP BY `p`.`month_no`
  UNION SELECT
          `p`.`month_key` AS `month_key`,
          `t`.`betrag`    AS `betrag`
        FROM (`haushaltsdaten`.`transaktion` `t` LEFT JOIN `haushaltsdaten`.`period_month` `p`
            ON (((`p`.`month_no` = month(`t`.`datum`)) AND (`p`.`year_no` = year(`t`.`datum`)))))
        GROUP BY `p`.`month_no`
  ORDER BY `month_key`;
