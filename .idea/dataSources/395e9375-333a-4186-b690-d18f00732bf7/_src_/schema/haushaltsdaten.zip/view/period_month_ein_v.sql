CREATE VIEW period_month_ein_v AS
  SELECT
    `p`.`month_key` AS `month_key`,
    `t`.`betrag`    AS `Betrag`
  FROM (`haushaltsdaten`.`transaktion` `t` LEFT JOIN `haushaltsdaten`.`period_month` `p`
      ON (((`p`.`month_no` = month(`t`.`datum`)) AND (`p`.`year_no` = year(`t`.`datum`)))))
  WHERE (`t`.`zahlungsart` = 'Einzahlung')
  UNION SELECT
          `p`.`month_key` AS `month_key`,
          NULL            AS `NULL`
        FROM (`haushaltsdaten`.`period_month` `p` LEFT JOIN `haushaltsdaten`.`transaktion` `t`
            ON (((`p`.`month_no` = month(`t`.`datum`)) AND (`p`.`year_no` = year(`t`.`datum`)))));
